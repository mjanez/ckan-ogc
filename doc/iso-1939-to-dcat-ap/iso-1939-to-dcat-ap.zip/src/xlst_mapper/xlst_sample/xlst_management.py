#!/usr/bin/env python3
## File: xlst_management.py
## Coding: UTF-8
## Author: Manuel Ángel Jáñez García (mjanez@tragsa.es)
## Institution: Tragsatec
## Project: EIKOS
## Goal: The goal of this script is is to map INSPIRE XML Metadata to GeoDCAT-AP.
## Parent: run.py 
""" Changelog:
    v1.0 - 8 Jul 2022: Create the first version
"""
# Update the version when apply changes
version = "1.0"

##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~##
##          xlst_management.py          ##
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~##

## Import libraries   
import lxml.etree as ET
from urllib.request import urlopen
from xlst_config import config_getParameters
import os

# Config default path
config_file = "../config.yml"


if __name__ == '__main__':
    
    log_folder, output_folder, inspire_info = config_getParameters(config_file)
    
    xml = ET.parse(urlopen(inspire_info["xml_url"]))
    xsl = ET.parse(urlopen(inspire_info["xsl_url"]))

    transform = ET.XSLT(xsl)

    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    #print(ET.tostring(transform(xml), pretty_print=True))
    try:
        xml_name = output_folder + "/GeoDCAT-AP_" + inspire_info["xml_url"].split("&ID=")[-1] + ".xml"
    except:
        try:
            xml_name = output_folder + "/GeoDCAT-AP_" + inspire_info["xml_url"].split("/")[-1]
        except:
            xml_name = output_folder + "/GeoDCAT-AP_sample_" + inspire_info["xml_url"][-5] + ".xml"
        
    print(xml_name)
    f =  open(xml_name, "wb")
    f.write(ET.tostring(transform(xml), pretty_print=True, encoding='UTF-8'))
    f.close()